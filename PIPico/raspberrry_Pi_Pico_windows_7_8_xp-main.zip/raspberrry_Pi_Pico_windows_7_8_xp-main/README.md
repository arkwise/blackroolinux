# raspberrry_Pi_Pico_windows 7,8,xp
How to install Raspberry pi Pico Driver in Windows 7,8,xp

Download the pico-serial.inf file and put it in the C:\Users\<username>\Documents and selecting that as the driver directory when the Device Manager Install Wizard popped-up worked a treat or go to computer - Manage - Device Manage and install the driver on the laptop or PC.
