#ifndef _IP6T_MARK_H_target
#define _IP6T_MARK_H_target

struct ip6t_mark_target_info {
	unsigned long mark;
};

#endif /*_IPT_MARK_H_target*/
