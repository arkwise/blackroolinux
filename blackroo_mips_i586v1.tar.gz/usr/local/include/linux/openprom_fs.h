#ifndef _LINUX_OPENPROM_FS_H
#define _LINUX_OPENPROM_FS_H

/*
 * The openprom filesystem constants/structures
 */

#define OPENPROM_SUPER_MAGIC 0x9fa1

#endif /* _LINUX_OPENPROM_FS_H */
