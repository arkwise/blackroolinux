#include <asm-generic/xor.h>
