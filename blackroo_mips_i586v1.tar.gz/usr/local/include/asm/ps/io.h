#ifndef __ASM_PS_IO_H 
#define __ASM_PS_IO_H 

#define PSX_HW_REG_BASE 0x1f800000

#endif
