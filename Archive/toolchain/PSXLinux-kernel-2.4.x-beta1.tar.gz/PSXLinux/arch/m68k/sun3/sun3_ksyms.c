#include <linux/module.h>
#include <linux/types.h>
#include <asm/dvma.h>
#include <asm/idprom.h>

/*
 * Add things here when you find the need for it.
 */
EXPORT_SYMBOL(sun3_dvma_malloc);
EXPORT_SYMBOL(idprom);
