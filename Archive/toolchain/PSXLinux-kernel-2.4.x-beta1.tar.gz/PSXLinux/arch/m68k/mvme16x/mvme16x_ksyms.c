#include <linux/module.h>
#include <linux/types.h>
#include <asm/ptrace.h>
#include <asm/mvme16xhw.h>
 
EXPORT_SYMBOL(mvme16x_config);
