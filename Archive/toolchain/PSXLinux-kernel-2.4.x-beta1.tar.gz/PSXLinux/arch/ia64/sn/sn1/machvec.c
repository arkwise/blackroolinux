#define MACHVEC_PLATFORM_NAME	sn1
#include <asm/machvec_init.h>
