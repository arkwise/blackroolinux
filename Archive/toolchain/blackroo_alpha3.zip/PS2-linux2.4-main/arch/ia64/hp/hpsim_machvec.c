#define MACHVEC_PLATFORM_NAME	hpsim
#include <asm/machvec_init.h>
