#include <sys/cdefs.h>

#ifndef __MEMCARD_SIMULATOR_H__
#define __MEMCARD_SIMULATOR_H__

_Noreturn
int simulate_memory_card();

#endif